<a href='https://ko-fi.com/C0C5RGOOP' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://storage.ko-fi.com/cdn/kofi2.png?v=3' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>

# patreon-dl

A Patreon downloader written in [Node.js](https://nodejs.org).

This repo contains the `patreon-dl` library and its command-line tool. For GUI application, check out [patreon-dl-gui](https://github.com/patrickkfkan/patreon-dl-gui).

### Features
- Access to patron-only content through cookie. This refers to content you have access to under your account. It does not include locked content that you don't have a subscription for.
- Download posts by user, in a collection or single post.
- Download products (aka shop purchases)
- Items included in downloads:
    - videos - but see [limitations](#limitations) on Patreon-hosted videos
    - images
    - audio
    - attachments
    - embedded videos
      - YouTube downloader built-in with configurable max resolution
      - Supports [external downloader](#embedded-videos--links---external-downloader)
- Save campaign and content info 
- Extensively configurable
- Browse downloaded content through integrated web server

You can run `patreon-dl` from the command-line or [use it as a library](./docs/Library.md) for your project. Node.js v20 or higher required.

### Limitations

**Embedded videos / links**

- Embedded links are not followed; only info about the embed is saved. Exception:
  - YouTube video link - in which case the video is downloaded; or
  - An external downloader is configured for the link provider.

For information on external downloaders, see the [Embedded videos / links - external downloader](#embedded-videos--links---external-downloader) section. Example config is provided for fetching YouTube (replacing the built-in downloader) and Vimeo videos.

**Patreon-hosted videos with DRM protection**

Some videos served by Patreon are now protected with DRM. Because these videos require a real-time decryption key available only during authorized streaming, they cannot be played back normally after being downloaded.

By default, `patreon-dl` will skip DRM-protected content to avoid broken downloads. If you still wish to download these files, you can force the download using:

- CLI: Use the `protected.media` option (see [example.conf](./example.conf)).
- Library: Use the `include.protectedMedia` option (see [documentation](./docs/Library.md)).

### FFmpeg dependency

[FFmpeg](https://ffmpeg.org) is required when downloading:
- videos that are provided only in streaming format; and
- embedded YouTube videos.

Not all video downloads require FFmpeg, but you should have it installed on your system anyway.

### Embedded YouTube videos / links

`patreon-dl` supports downloading embedded YouTube videos or from embedded YouTube video links.

#### Deno dependency

The built-in YouTube downloader runs code retrieved from YouTube or Google servers. If [Deno](https://deno.com/) is installed on your system, it will be used to execute this code within a secure, sandboxed environment. Without Deno, the code runs without isolation, increasing the risk of security vulnerabilities such as unauthorized access, data corruption, or malicious behavior. For this reason, installing Deno is strongly recommended.

When needed, the downloader will attempt to invoke the `deno` command. If it’s not found, it will default to unsafe execution. If Deno is installed but the `deno` executable isn’t available in your system’s PATH, you can manually specify its location using the `--deno` CLI option or `path.to.deno` config file option:

```
// CLI
$ patreon-dl --deno path/to/deno ...

// Config file
[downloader]
path.to.deno = "path/to/deno"
...
```

#### Premium access / "Login required" error

If you have a YouTube Premium subscription, you can connect `patreon-dl` to your account and download videos at qualities available only to Premium accounts (e.g. '1080p Premium'). You will also need to connect to an account (not necessarily Premium) if you get a "Login required" error message during download.

For CLI users, you would configure `patreon-dl` as follows:

```
$ patreon-dl --configure-youtube
```

### Embedded videos / links - external downloader

You can specify external programs to download embedded videos or from embedded links. For YouTube videos, this will replace the built-in downloader.

See the [example config](./example-embed.conf) on how to configure an external downloader to fetch YouTube, Vimeo and SproutVideo content through [yt-dlp](https://github.com/yt-dlp/yt-dlp). Helper scripts bundled with `patreon-dl` are used in the case of Vimeo and SproutVideo ([patreon-dl-vimeo.js](./bin/patreon-dl-vimeo.js) and [patreon-dl-sprout.js](./bin/patreon-dl-sprout.js) respectively).

## Installation

1. First, install [Node.js](https://nodejs.org). 
2. Then, install [FFmpeg](https://ffmpeg.org) (if you are going to download videos).
3. Then, in a terminal, run the following command:

   ```
   $ npm i -g patreon-dl
   ```

   The `-g` option is for installing `patreon-dl` globally and have the CLI executable added to the PATH. Depending on your usage, you might not need this.

## CLI usage

```
$ patreon-dl [OPTION]... URL
```

### OPTION

| Option    | Alias | Description |
|-----------|-------|-------------|
| `--help`  | `-h`  | Display usage guide |
| <code><nobr>--config-file &lt;path&gt;</nobr></code> | `-C` | Load [configuration file](#configuration-file) at `<path>` for setting full options |
| `--cookie <string>` | `-c` | Cookie for accessing patron-only content; [how to obtain cookie](https://github.com/patrickkfkan/patreon-dl/wiki/How-to-obtain-Cookie). |
| `--ffmpeg <path>` | `-f` | Path to FFmpeg executable |
| `--deno <path>` | `-d` | Path to Deno executable |
| `--out-dir <path>` |`-o` | Directory to save content |
| `--log-level <level>` | `-l` | Log level of the console logger: `info`, `debug`, `warn` or `error`; set to `none` to disable the logger. |
| `--no-prompt` | `-y` | Do not prompt for confirmation to proceed |
| `--dry-run`   |      | Run without writing files to disk (except logs, if any). Intended for testing / debugging. |
| <code><nobr>--list-tiers &lt;creator&gt;</nobr></code> | | <p>List tiers for the given creator(s). Separate multiple creators with a comma.</p>The purpose of this is to let you find out what tier IDs to set for `posts.in.tier` filtering option under `include` section of [configuration file](#configuration-file). |
| <code><nobr>--list-tiers-uid &lt;user ID&gt;</nobr></code> | | Same as `--list-tiers`, but takes user ID instead of vanity. |
| <code><nobr>--list-posts &lt;creator&gt;</nobr></code> | | <p>List posts by the given creator(s). Separate multiple creators with a comma.</p> |
| <code><nobr>--list-posts-uid &lt;user ID&gt;</nobr></code> | | Same as `--list-posts`, but takes user ID instead of vanity. |
| `--configure-youtube` | | <p>Configure YouTube connection.</p>`patreon-dl` supports downloading embedded YouTube videos. If you have a YouTube Premium account, you can connect `patreon-dl` to it for downloading Premium-quality streams. You will also need to connect to an account if you get a "Login required" error message during download.|

### URL

#### Supported URL formats

```
// Download products from a creator's shop
https://www.patreon.com/<creator>/shop
https://www.patreon.com/c/<creator>/shop
https://www.patreon.com/cw/<creator>/shop

// Download a single product
https://www.patreon.com/<creator>/shop/<slug>-<product_id>

// Download posts by creator
https://www.patreon.com/<creator>/posts
https://www.patreon.com/c/<creator>/posts
https://www.patreon.com/cw/<creator>/posts
https://www.patreon.com/user/posts?u=<user_id>

// Dowload a single post
https://www.patreon.com/posts/<post_id>
https://www.patreon.com/posts/<slug>-<post_id>

// Download posts in a collection
https://www.patreon.com/collection/<collection_id>

```

#### Custom URLs

Some creators host their Patreon pages on custom domains. You can provide this custom URL to `patreon-dl`, which will download posts from the associated creator.

#### Multiple URLs

You may specify multiple URLs by separating them with a comma. E.g.:

```
// First download posts by johndoe, followed by posts by janedoe.
$ patreon-dl "https://www.patreon.com/johndoe/posts,https://www.patreon.com/janedoe/posts"
```

#### Supplying URLs through file

You can also use a file to supply URLs to `patreon-dl`. For example, you can have a `urls.txt` that has the following content:

```
# Each URL is placed in its own line
# Comments (lines starting with '#') will be ignored

https://www.patreon.com/johndoe/posts
https://www.patreon.com/janedoe/posts

```

You can then pass `urls.txt` to `patreon-dl`:

```
$ patreon-dl urls.txt
```

In this file, you can also override `include` options provided in a [configuration file](#configuration-file) passed to `patreon-dl` (through the `-C` option). `include` options allow you specify what to include in downloads. This overriding mechanism allows you to specify different content to download for each target URL. For example, you might have the following `include` option in your configuration file:

```
...

[include]

# Include posts that belong only to tier ID '-1' (public tier)
posts.in.tier = -1

...
```

Then, in your `urls.txt`, you can override as follows:

```
# URL 1
https://www.patreon.com/johndoe/posts

# Override 'posts.in.tier = -1' in [include] section of configuration file.
# This will cause downloader to download posts from URL 1 belonging to tier with
# ID '123456' or '789100'.

include.posts.in.tier = 123456, 789100

# Other include options - they basically have the same name as those
# in the configuation file, but prepended with 'include.':
#
# include.locked.content
# include.posts.with.media.type
# include.posts.published.after
# include.posts.published.before
# include.campaign.info
# include.content.info
# include.preview.media
# include.content.media
# include.protected.media
# include.all.media.variants
# include.images.by.filename
# include.audio.by.filename
# include.attachments.by.filename
# include.comments

# URL 2 
https://www.patreon.com/janedoe/posts

# If you don't place any 'include.*' statements here, the downloader will use
# options from configuration file or default values if none provided.

# URL 3
...

```

### Directory structure

Content is saved with the following directory structure:
```
out-dir
    ├── campaign
        ├── campaign_info
        ├── posts
        │   ├── post 1
        │   │   ├── post_info
        │   │   ├── images
        │   │   ├── ...
        │   ├── post 2
        │       ├── post_info
        │       ├── images
        │       ├── ...
        ├──shop
            ├── product 1
                ├── product_info
                ├── content_media
                ├── ...
```


### Configuration file

Command-line options are limited. To access the full range of options, create a configuration file and pass it to `patreon-dl` with the (capital) `-C` option.

Refer to the [example config](./example.conf) to see what options are offered. Also see [How to obtain Cookie](https://github.com/patrickkfkan/patreon-dl/wiki/How-to-obtain-Cookie).

Note that you can override an option from a configuration file with one provided at the command-line, provided of course that a command-line equivalent is available.

## Browsing downloaded content

`patreon-dl` comes with a web server that allows you to browse downloaded content. To start the web server:

```
$ patreon-dl-server [OPTION]
```

### OPTION

| Option    | Alias | Description |
|-----------|-------|-------------|
| `--help`  | `-h`  | Display usage guide |
| `--data-dir <dir>` |`-i` | Directory containing downloaded content. Default: current working directory |
| `--port <number>` |`-p` | Web server port. Default: `3000`, or a random port if `3000` is already in use. |
| `--log-level <level>` | `-l` | Log level of the console logger: `info`, `debug`, `warn` or `error`; set to `none` to disable the logger. Default: `info` |
| `--log-file <file>` | `-f` | Save logs to `<file>`. |


### Example usage

Say you downloaded something with `patreon-dl`:

```
$ patreon-dl -o "C:\PatreonDownloads" <url>
```

This will download content to `C:\PatreonDownloads`. To view the downloaded content, start `patreon-dl` server as follows:

```
$ patreon-dl-server -i "C:\PatreonDownloads"

...info: Web server is running on <URL>
```

Note the URL shown in the output. Open this URL in a web browser to begin viewing the downloaded content.

> Keep in mind that the web server is in no way secure. It is meant for local browsing and should not be exposed to outside parties!

## Changelog

3.8.1
- YT embeds: obtain images directly from YT instead of Patreon API data, since the latter could give 0-byte content ([@Fabelwesen](https://github.com/Fabelwesen) - [#120](https://github.com/patrickkfkan/patreon-dl/issues/120)).

3.8.0
- Add support for custom URLs (creators hosting Patreon pages on their own domains) ([@lucasoskorep](https://github.com/lucasoskorep) - [PR #129](https://github.com/patrickkfkan/patreon-dl/pull/129)).
- Fix YT download errors ([#132](https://github.com/patrickkfkan/patreon-dl/issues/132)).
- Browse: set title tag based on content ([#127](https://github.com/patrickkfkan/patreon-dl/issues/127)).
- CLI: add `--list-posts` / `--list-posts-uid` ([#126](https://github.com/patrickkfkan/patreon-dl/issues/126)).

3.7.1
- Check and skip download of Patreon-hosted videos that are protected by DRM; add `include.protectedMedia` / `protected.media` option.
- Fix campaign not found when targeting collections ([#124](https://github.com/patrickkfkan/patreon-dl/issues/124)).

v3.7.0
- Vimeo download script: fetch full player URL ([#118](https://github.com/patrickkfkan/patreon-dl/issues/118))
- Fix downloaded posts missing content / teaser ([@Fabelwesen](https://github.com/Fabelwesen) - [#119](https://github.com/patrickkfkan/patreon-dl/issues/119))
- Add "max content width" option to browse settings ([#122](https://github.com/patrickkfkan/patreon-dl/issues/122))
- Map inline post links to local server routes (contrib by [@Fabelwesen](https://github.com/Fabelwesen) - [#121](https://github.com/patrickkfkan/patreon-dl/issues/121))
- Support additional fields in `media.filename.format` ([patreon-dl-gui#51](https://github.com/patrickkfkan/patreon-dl-gui/issues/51))
- YT downloader: fix error in n/sig decipher function extraction

v3.6.1
- Fix Embedly download script error on retrying with alternative URL.

v3.6.0
- Browse: affix nav links (previous / next post) to viewport bottom if post content overflows ([patreon-dl-gui#41](https://github.com/patrickkfkan/patreon-dl-gui/issues/41))
- Fix error when Deno path contains spaces ([patreon-dl-gui#42](https://github.com/patrickkfkan/patreon-dl-gui/issues/42))
- Add SproutVideo download script ([patreon-dl-gui#43](https://github.com/patrickkfkan/patreon-dl-gui/issues/43))
- Fix YouTube download returning "auth required" error

v3.5.0
- Add support for downloading from "shop" URLs (e.g. `https://www.patreon.com/<creator>/shop`). This will download all products from a creator's shop.
  - Add `productsPublished` / `products.published.after` / `products.published.before` option to set publish date criteria of products included in download.
  - Since `stopOn` / `stop.on` option now also applies to products, the `postPreviouslyDownloaded` and `postPublishDateOutOfRange` values have been deprecated in favor of `previouslyDownloaded` and `publishDateOutOfRange`, respectively.
- Add Collections support. Collection info is now saved when downloading posts. This means you can browse posts by collection. ([#107](https://github.com/patrickkfkan/patreon-dl/issues/107))
- (Browse) Add search functionality ([#106](https://github.com/patrickkfkan/patreon-dl/issues/106))
- Add Tags support. Tag info is now saved when downloading posts. This means you can filter posts by tag.
- Add `include.mediaThumbnails` option

v3.4.0
- Fix "no posts found" on "cw" pages ([patreon-dl-gui#30](https://github.com/patrickkfkan/patreon-dl-gui/issues/30))
- Fix YouTube streams returning 403 error ([patreon-dl-gui#31](https://github.com/patrickkfkan/patreon-dl-gui/issues/31))
- Add `pathToDeno` / `--deno` / `path.to.deno` option (used by built-in YouTube downloader)
- Merged PRs:
  - Allow directory to be a symlink ([@piperswe](https://github.com/piperswe) - [#101](https://github.com/patrickkfkan/patreon-dl/pull/101))
  - Add Github actions ([@piperswe](https://github.com/piperswe) - [#102](https://github.com/patrickkfkan/patreon-dl/pull/102))
  - Add `maxVideoResolution` / `max.video.resolution` option to limit video downloads to a maximum resolution (see [example.conf](./example.conf)) ([@eisenbruch](https://github.com/eisenbruch) - [#105](https://github.com/patrickkfkan/patreon-dl/pull/105)) - extended to include site-hosted videos

v3.3.1
- Fix bugs affecting library usage:
  - `DB.getInstance()` returning same instance despite different DB path
  - `API.getInstance()` returning same instance despite different DB instance
  - DB not closed when downloader ends or web server stops

v3.3.0
- Fix:
  - YouTube stream fetching error ([patreon-dl-gui#28](https://github.com/patrickkfkan/patreon-dl-gui/issues/28))
  - Unsupported option error with FFmpeg v7.1.0 ([#97](https://github.com/patrickkfkan/patreon-dl/issues/97))
- Browse:
  - Add next / previous links to post page ([#93](https://github.com/patrickkfkan/patreon-dl/issues/93))
  - Fix media filter error when tier selected but not "Post"
- Process linked attachments in body of posts ([patreon-dl-gui#27](https://github.com/patrickkfkan/patreon-dl-gui/issues/27))
- Some DB optimizations (contrib by @[piperswe](https://github.com/piperswe) - PR #[95](https://github.com/patrickkfkan/patreon-dl/pull/95))

v3.2.1
- Fix log file path sometimes not sanitized properly on Windows
- API: add support for passing request options to `getCampaign()`
- CLI: add support for using request options from conf file when running with `--list-tiers` / `--list-tiers-uid`

v3.2.0
- Fix:
  - "Initial data not found" error in `patreon.com/cw` pages ([#85](https://github.com/patrickkfkan/patreon-dl/issues/85)) and custom-domain pages
  - FFmpeg v7.x compatibility issues ([#86](https://github.com/patrickkfkan/patreon-dl/issues/86))
  - Dry-run mode executing ops that should have been skipped
  - Wrong log file path returned in some cases
  - Various YouTube downloading issues
- Add:
  - Support passing options to `yt-dlp` in Vimeo download script
  - Support case-sensitivity flag in `config.include.mediaByFilename` options
- Browse:
  - Show inline images within post body
  - Show YouTube embed HTML content if video not downloaded ([#87](https://github.com/patrickkfkan/patreon-dl/issues/87))
  - Display "show more" toggle for long post bodies
- API:
  - `Downloader.getCampaign(params)`: enable lookup by `params.campaignId`

v3.1.0
- Defer database initialization until downloader starts
- UI: fix post column width possibly exceeding screen width
- Add `request.userAgent` option

v3.0.0
- Add support for browsing downloaded content through integrated web server. Note: this feature will not work for downloads made with previous versions of `patreon-dl`.

v2.4.3
- Fix YouTube embeds failing to download due to YT changes
- Add fallback download logic to Vimeo download script
- Fix error when downloading video ([#75](https://github.com/patrickkfkan/patreon-dl/issues/75))

v2.4.2
- Fix YouTube embeds failing to download due to YT changes
- Fix slow YouTube downloads ([#66](https://github.com/patrickkfkan/patreon-dl/issues/66))
- Other minor fixes

v2.4.1
- Fix Vimeo download script obtaining and downloading from player URL in embed HTML ([#65](https://github.com/patrickkfkan/patreon-dl/issues/65))
- Add `post-url` and `cookie` to available external downloader exec params
- API changes (non-breaking):
  - Expose `cookie` in `DownloaderConfig`


v2.4.0
- Support additional URL format: `https://www.patreon.com/cw/<creator>/posts`
- Add `stopOn` option ([#63](https://github.com/patrickkfkan/patreon-dl/issues/63))
- Add `proxy` option ([#62](https://github.com/patrickkfkan/patreon-dl/issues/62))
- Fix Vimeo download script
- Fix YouTube embeds failing to download due to YT changes
- API changes (non-breaking):
  - Expose `URLHelper`, `FetcherError`
  - Add `getDefaultDownloaderOptions()`
  - `ConsoleLogger` / `FileLogger`: add `getDefaultConfig()`
- Required Node version bumped to v20.18.1 or higher

v2.3.0
- Add `podcast` type to `include.postsWithMediaType` option
- Add `include.comments` option
- Fix videos not downloaded in podcast-type posts ([#56](https://github.com/patrickkfkan/patreon-dl/issues/56))

v2.2.0
- Widen scope of external downloaders to any type of embed (previously only works for video embeds) ([#51](https://github.com/patrickkfkan/patreon-dl/issues/51))
- YouTube downloading now covers embedded YT links
- Fix attachment filenames sometimes have wrong extension

v2.1.1
- Fix multiple abort signal listeners triggering warning ([#48](https://github.com/patrickkfkan/patreon-dl/issues/48))
- Fix YouTube embeds failing to download due to YT changes ([#50](https://github.com/patrickkfkan/patreon-dl/issues/50))
- Fix inline images of posts sometimes missing from downloads
- Fix status cache: target marked as downloaded without errors despite having errors at task creation stage

v2.1.0
- Fix attachment downloads following API changes ([#40](https://github.com/patrickkfkan/patreon-dl/issues/40))
- Add support for URL format: `https://www.patreon.com/c/<creator>/posts`
- Check and resolve conflicting destination paths ([#38](https://github.com/patrickkfkan/patreon-dl/issues/38))
- Parse inline content media ([#40](https://github.com/patrickkfkan/patreon-dl/issues/40))

v2.0.0
- Replace [node-fetch](https://github.com/node-fetch/node-fetch) with Fetch API; required Node.js version bumped to v18 or higher.
- Update dependencies and libraries
- New `include` options:
  - `include.postsPublished` ([#29](https://github.com/patrickkfkan/patreon-dl/issues/29))
  - `include.mediaByFilename` ([#33](https://github.com/patrickkfkan/patreon-dl/issues/33))
- Bug fixes:
  - 403 error when downloading YouTube embeds
  - Only first of multiple targets downloaded ([#26](https://github.com/patrickkfkan/patreon-dl/issues/26))

v1.7.0
- Download next batch of posts before expiry of 'next' URL (fixes [#22](https://github.com/patrickkfkan/patreon-dl/issues/22))
- Add `--dry-run` / `dryRun` option
- Support URL format `https://www.patreon.com/posts/<post_id>`

v1.6.2
- Fix 'campaign ID not found' error due to Patreon changes

v1.6.1
- Fix file extension sometimes missing ([#20](https://github.com/patrickkfkan/patreon-dl/issues/20))

v1.6.0
- Add external downloader support for embedded videos

v1.5.0
- Add support for fetching by user ID instead of creator vanity ([#18](https://github.com/patrickkfkan/patreon-dl/issues/18)):
  - Support URL format `https://www.patreon.com/user/posts?u=<user_id>`
  - Overload `PatreonDownloader.getCampaign()` to take `userId` arg
  - CLI: add `--list-tiers-uid`

v1.4.0
- Add ability to filter posts by tier ([#8](https://github.com/patrickkfkan/patreon-dl/issues/8))
- CLI:
  - Add `--list-tiers`
  - Add support for target-specific `include` options
  - Print summary at the end for multiple target URLs ([#13](https://github.com/patrickkfkan/patreon-dl/issues/13))

v1.3.0
- Add support for multiple target URLs
- Add `content.publishDate` field to the content dir name format ([PR #12](https://github.com/patrickkfkan/patreon-dl/pull/12) by [kazuoteramoto](https://github.com/kazuoteramoto))
- Bug fixes

v1.2.2
- Fix wrong file extension for some content types
- Fix YouTube API requests throwing errors due to YT changes

v1.2.1
- Bug fixes

v1.2.0
- Add support for granular control over:
  - posts to include in download based on type of media contained
  - the type of media to download
- Bug fixes

v1.1.1
- Fix initial data parsing following Patreon changes

v1.1.0
- Add support for downloading embedded YouTube videos

v1.0.1
- Fix missing types when importing as library
- Fix link in this README

v1.0.0
- Initial release

---
This project is licensed under the MIT License and includes third-party software—see the [NOTICE](./NOTICE) file for attributions.
